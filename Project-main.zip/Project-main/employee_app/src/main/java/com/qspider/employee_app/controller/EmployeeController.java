package com.qspider.employee_app.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.qspider.employee_app.dto.Employee;
import com.qspider.employee_app.response.ResponseStructure;
import com.qspider.employee_app.service.EmployeeService;
@RestController
public class EmployeeController 
{
	@Autowired
	EmployeeService employeeService;
	@PostMapping("/register")
	//url--> localhost:8080/register
	public ResponseEntity<?> registerEmp(@RequestBody Employee emp)
	{
		ResponseStructure<?> employee = employeeService.registerEmp(emp);
		return new ResponseEntity<>(employee,HttpStatus.CREATED);
	}
	
	@GetMapping("/getDetails")
	//localhost:8080/getDetails/email=Gokul@027&password=Gokul@027
	public ResponseEntity<?>empDetails(@RequestParam String email,@RequestParam String password)
	{
		ResponseStructure<?> employee = employeeService.loginRequest(email, password);
		return new ResponseEntity<>(employee,HttpStatus.FOUND);
	}
	@GetMapping("/get")
	public ResponseEntity<?> getAllEmployee()
	{
		ResponseStructure<?> allemployee = employeeService.getAllEmployee();
		return new ResponseEntity<>(allemployee,HttpStatus.FOUND);
	}
	
	@GetMapping("/getEmpByid")
	//  localhost:8080/getEmpById?employeeId=2
	public Employee getEmployeeById(@RequestParam int employeeId)
	{
		Employee employee = employeeService.getEmployeeById(employeeId);
		return employee;
	}
	
	@PutMapping("/update")
	public String updateEmp(@RequestBody Employee employee)
	{
		Employee emp = employeeService.updateEmp(employee);
		return emp.getName()+" Your record updated";
	}
	
	@DeleteMapping("/delete")
	public String deleteEmp(@RequestParam int employeeId)
	{
		String string = employeeService.deleteEmp(employeeId);
		return string;
	}	
}