package com.qspider.employee_app.Exception;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
@RestControllerAdvice
public class ExceptionController 
{
	
	@ExceptionHandler(value = WrongPasswordException.class)
	public ResponseEntity<?> wrongPasswordException(WrongPasswordException e)
	{
		ApiErrorResponseStructure errorpassword= new ApiErrorResponseStructure();
		errorpassword.setMessage(e.getMessage());
		errorpassword.setDatetime(LocalDateTime.now());
		errorpassword.setExceptionclass(e.getClass());
		return new ResponseEntity<>(errorpassword,HttpStatus.BAD_REQUEST);
	}
	@ExceptionHandler(value=WrongEmailException.class)
	public ResponseEntity<?>wrongEmailException (WrongEmailException ex)
	{
		ApiErrorResponseStructure errorEmail= new ApiErrorResponseStructure();
		errorEmail.setMessage(ex.getMessage());
		errorEmail.setDatetime(LocalDateTime.now());
		errorEmail.setExceptionclass(ex.getClass());
		return new ResponseEntity<>(errorEmail,HttpStatus.BAD_REQUEST);
	}
}
