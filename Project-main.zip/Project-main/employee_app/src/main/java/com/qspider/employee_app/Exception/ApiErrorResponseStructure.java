package com.qspider.employee_app.Exception;

import java.time.LocalDateTime;
import lombok.Data;
@Data
public class ApiErrorResponseStructure 
{
	String message;
	LocalDateTime datetime;
	Class exceptionclass;
}
