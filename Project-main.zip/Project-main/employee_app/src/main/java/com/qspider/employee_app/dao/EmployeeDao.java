package com.qspider.employee_app.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.qspider.employee_app.dto.Employee;
import com.qspider.employee_app.repository.EmployeeRepository;

@Repository
public class EmployeeDao  
{
	@Autowired
	EmployeeRepository employeeRepository;
	public Employee registerEmp(Employee employee) 
	{
		Employee dbEmp = employeeRepository.save(employee);
		return dbEmp;
	}
	public List<Employee> getAllEmployee() 
	{
		List<Employee> list = employeeRepository.findAll();
		return list;
	}
	public Employee getEmployeeById(int employeeId)
	{
		Optional<Employee> optional = employeeRepository.findById(employeeId);
		if(optional.isPresent())
		{
			return optional.get();
		}
		return null;
	}
	public Employee updateEmp(Employee employee) 
	{
		Optional<Employee> optional = employeeRepository.findById(employee.getEmployeeid());
		if(optional.isPresent())
		{
			Employee employee2 = employeeRepository.save(employee);
			return employee2;
		}
		return null;
	}
	public String deleteEmp(int employeeId) 
	{
		Optional<Employee> optional = employeeRepository.findById(employeeId);
		if(optional.isPresent())
		{
			employeeRepository.delete(optional.get());
			return optional.get().getName()+" Employee data deleted successfully";
		}
		return null;
	}
	public Employee getEmpbyEmail(String email) {
		Optional<Employee> byEmail =employeeRepository.findByEmail(email);
		Employee emp=byEmail.get();
		return emp;
	}
}
