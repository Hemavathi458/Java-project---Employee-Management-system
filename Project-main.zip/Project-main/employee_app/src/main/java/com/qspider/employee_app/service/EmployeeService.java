package com.qspider.employee_app.service;
import java.time.LocalDateTime;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qspider.employee_app.Exception.WrongEmailException;
import com.qspider.employee_app.Exception.WrongPasswordException;
import com.qspider.employee_app.dao.EmployeeDao;
import com.qspider.employee_app.dto.Employee;
import com.qspider.employee_app.response.ResponseStructure;

@Service
public class EmployeeService {
	@Autowired
	EmployeeDao employeeDao;
	
	public ResponseStructure<?> registerEmp(Employee employee) 
	{
		Employee emp = employeeDao.registerEmp(employee);
		ResponseStructure<Employee> structure = new ResponseStructure();
		structure.setData(emp);
		structure.setDatetime(LocalDateTime.now());
		structure.setStatusCode(201);
		structure.setMessage("Employee Registration success");
		return structure;
	}

	public ResponseStructure<List<Employee>> getAllEmployee() 
	{
		List<Employee> allEmployee = employeeDao.getAllEmployee();
		ResponseStructure<List<Employee>> structure = new ResponseStructure();
		structure.setData(allEmployee);
		structure.setDatetime(LocalDateTime.now());
		structure.setStatusCode(302);
		structure.setMessage("All Employee data fetched successfully");
		return structure;
	}

	public Employee getEmployeeById(int employeeId) 
	{
		Employee employee = employeeDao.getEmployeeById(employeeId);
		return employee;
	}

	public Employee updateEmp(Employee employee) 
	{
		Employee employee2 = employeeDao.updateEmp(employee);
		return employee2;
	}
	public String deleteEmp(int employeeId) 
	{
		String string = employeeDao.deleteEmp(employeeId);
		return string;
	}
	public ResponseStructure<?> loginRequest(String email,String password)
	{
		ResponseStructure<Employee> responsestruture =new ResponseStructure<Employee>();
		Employee loginrequest=employeeDao.getEmpbyEmail(email);
		if(loginrequest!=null)
		{
			if(loginrequest.getPassword().equals(password))
			{
				responsestruture.setData(loginrequest);
				responsestruture.setDatetime(LocalDateTime.now());
				responsestruture.setMessage("Employee found");
				responsestruture.setStatusCode(302);
				return responsestruture;
			}
			throw new WrongPasswordException();
		}
		throw new WrongEmailException();
		//return null;
	}
}
