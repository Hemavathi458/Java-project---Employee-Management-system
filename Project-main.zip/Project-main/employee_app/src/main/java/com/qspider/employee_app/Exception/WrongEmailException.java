package com.qspider.employee_app.Exception;

public class WrongEmailException extends RuntimeException
{
	 public String getMessage()
	 {
		 return "invalid Mail Id";
	 }
}
