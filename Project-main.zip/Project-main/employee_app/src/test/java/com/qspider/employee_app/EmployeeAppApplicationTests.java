package com.qspider.employee_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
